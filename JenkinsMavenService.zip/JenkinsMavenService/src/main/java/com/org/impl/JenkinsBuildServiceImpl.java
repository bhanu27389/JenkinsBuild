package com.org.impl;

import com.org.model.Response;
import com.org.service.JenkingBuildInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
@Slf4j
public class JenkinsBuildServiceImpl implements JenkingBuildInfo {

    @Value("${jenkinUrl}")
    private String jenkinUrl;

    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        return builder.build();
    }

    public Response getBuildInfo (RestTemplate restTemplate) throws ParseException {
        ResponseEntity<String> quote = restTemplate.getForEntity(jenkinUrl, String.class);
        if (Objects.isNull(quote)) {
            //We can either go forward with another scenario or handle exception based on story
            return null;
        }
        Response responseObj = new Response();
        //Json Response values will be mapped from the http response we get from api call
        responseObj.setTotalBuilds(2011);
        //Assuming we calculate average time using build start time and end time that we get from the response
        String time = "2014-04-28 ,2014-04-25";
        List<Long> buildTimes = getAveTime(time);
        responseObj.setAvgRunTime(average(buildTimes));
        //log.info(quote.toString());
        return responseObj;
    }

    private static List<Long> getAveTime(String time) throws ParseException {
        List<Long> differences = new ArrayList<>();
        String[] dates = time.split(",");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        for(int i = 0; i<dates.length; i = i+2){
            differences.add(differenceBetween(sdf.parse(dates[i+1]),sdf.parse(dates[i])));
        }
        return differences;
    }

    public static long differenceBetween(Date date1, Date date2){
        long MILLIS_PER_DAY = 24 * 3600 * 1000;
        long msDiff= date1.getTime() - date2.getTime();
        long daysDiff = Math.round(msDiff / ((double)MILLIS_PER_DAY));
        return daysDiff;
    }
    public static double average(List<Long> diffs){
        double sum = 0;
        for(Long d : diffs){
            sum += d;
        }
        return sum/diffs.size();
    }
}
