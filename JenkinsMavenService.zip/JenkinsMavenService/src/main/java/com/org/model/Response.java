package com.org.model;

import lombok.Data;

@Data
public class Response {

        private int totalBuilds;
        private double avgRunTime;

    public Response(int totalBuilds, double avgRunTime) {
        this.totalBuilds = totalBuilds;
        this.avgRunTime = avgRunTime;
    }

    public Response() {
    }
}
