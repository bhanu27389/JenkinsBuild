package com.org.service;

import com.org.model.Response;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.text.ParseException;

@Component
public interface JenkingBuildInfo {

   Response getBuildInfo(RestTemplate restTemplate) throws ParseException;
}
