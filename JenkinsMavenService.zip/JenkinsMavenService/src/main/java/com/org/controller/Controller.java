package com.org.controller;

import com.org.model.Response;
import com.org.service.JenkingBuildInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@Slf4j
public class Controller {

    @Autowired
    private JenkingBuildInfo jenkinsBuildInfo;

    @Autowired
    RestTemplate restTemplate;

    //Controller service to get jenkins build information
    @GetMapping("/job/builds")
    public Response getBuild() throws Exception{
        Response response = jenkinsBuildInfo.getBuildInfo(restTemplate);
        log.info(response.toString());
        return response;
    }
}
